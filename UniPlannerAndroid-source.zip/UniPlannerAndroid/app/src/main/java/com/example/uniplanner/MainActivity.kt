package com.example.uniplanner

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class UniClass(
    val id: Int, val name: String, val day: Int, val hour: Int, val minute: Int,
    val room: String, val note: String, val reminders: List<Int>
)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("uni_planner", MODE_PRIVATE) }
    private val classes = mutableListOf<UniClass>()
    private lateinit var listBox: LinearLayout
    private lateinit var nameInput: EditText
    private lateinit var roomInput: EditText
    private lateinit var noteInput: EditText
    private lateinit var reminderInput: EditText
    private lateinit var daySpinner: Spinner
    private var hour = 9
    private var minute = 0
    private lateinit var timeButton: Button

    private val days = listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه")
    private val dayValues = listOf(Calendar.SATURDAY, Calendar.SUNDAY, Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadClasses()
        createChannel()
        requestNotificationPermission()
        buildUi()
        renderClasses()
        if (Build.VERSION.SDK_INT >= 31 && !getSystemService(AlarmManager::class.java).canScheduleExactAlarms()) {
            // The app remains usable; exact alarm access can be enabled in Android settings.
        }
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 32, 36, 36)
            setBackgroundColor(0xFFF5F7FA.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "برنامه‌ریز دانشگاه"
            textSize = 26f; setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF123B3A.toInt()); gravity = Gravity.CENTER
        }
        root.addView(title, match())
        root.addView(label("کلاس جدید", 20f, true), marginTop(match(), 24))

        nameInput = edit("نام درس (مثلاً برنامه‌سازی)")
        root.addView(nameInput, marginTop(match(), 8))

        daySpinner = Spinner(this)
        daySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, days)
        root.addView(daySpinner, marginTop(match(), 8))

        timeButton = Button(this).apply { text = "ساعت شروع: 09:00"; setOnClickListener {
            TimePickerDialog(this@MainActivity, { _, h, m ->
                hour = h; minute = m; timeButton.text = "ساعت شروع: %02d:%02d".format(h, m)
            }, hour, minute, true).show()
        } }
        root.addView(timeButton, marginTop(match(), 8))

        roomInput = edit("کلاس / استاد (اختیاری)")
        root.addView(roomInput, marginTop(match(), 8))

        reminderInput = edit("دقایق قبل از کلاس؛ مثال: 45, 20, 7")
        reminderInput.inputType = android.text.InputType.TYPE_CLASS_TEXT
        root.addView(reminderInput, marginTop(match(), 8))
        root.addView(label("هر تعداد زمان دلخواه وارد کن؛ با ویرگول جدا کن. مثال: 60, 15, 3", 13f, false), marginTop(match(), 4))

        noteInput = edit("تکالیف، پروژه‌ها و یادداشت‌های این درس")
        noteInput.minLines = 3
        noteInput.gravity = Gravity.TOP or Gravity.START
        root.addView(noteInput, marginTop(match(), 8))

        val add = Button(this).apply {
            text = "ذخیره کلاس و تنظیم هشدارها"
            setOnClickListener { addClass() }
        }
        root.addView(add, marginTop(match(), 12))

        root.addView(label("کلاس‌های ثبت‌شده", 20f, true), marginTop(match(), 28))
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox, marginTop(match(), 8))

        val foot = TextView(this).apply {
            text = "اطلاعات روی همین گوشی ذخیره می‌شود. برای نمایش اعلان‌ها، مجوز اعلان را فعال نگه دار."
            textSize = 12f; setTextColor(0xFF5D6875.toInt())
        }
        root.addView(foot, marginTop(match(), 20))
    }

    private fun addClass() {
        val name = nameInput.text.toString().trim()
        if (name.isEmpty()) { nameInput.error = "نام درس را وارد کن"; return }
        val reminders = reminderInput.text.toString().split(",", "،", ";")
            .mapNotNull { it.trim().toIntOrNull() }.filter { it > 0 && it <= 10080 }.distinct().sortedDescending()
        if (reminders.isEmpty()) { reminderInput.error = "حداقل یک زمان بر حسب دقیقه وارد کن؛ مثلاً 15"; return }
        val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
        val item = UniClass(id, name, dayValues[daySpinner.selectedItemPosition], hour, minute,
            roomInput.text.toString().trim(), noteInput.text.toString().trim(), reminders)
        classes.add(item)
        saveClasses()
        schedule(item)
        nameInput.setText(""); roomInput.setText(""); noteInput.setText(""); reminderInput.setText("")
        Toast.makeText(this, "کلاس ذخیره شد", Toast.LENGTH_SHORT).show()
        renderClasses()
    }

    private fun renderClasses() {
        if (!::listBox.isInitialized) return
        listBox.removeAllViews()
        if (classes.isEmpty()) {
            listBox.addView(label("هنوز کلاسی ثبت نکرده‌ای.", 15f, false))
            return
        }
        classes.sortedWith(compareBy<UniClass>({ dayValues.indexOf(it.day) }, { it.hour }, { it.minute })).forEach { item ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(24, 18, 24, 18)
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            card.addView(label("${item.name} — ${days[dayValues.indexOf(item.day)]}", 18f, true))
            card.addView(label("%02d:%02d".format(item.hour, item.minute) + if (item.room.isNotBlank()) " | ${item.room}" else "", 14f, false))
            card.addView(label("هشدارها: " + item.reminders.joinToString("، ") { "$it دقیقه قبل" }, 13f, false))
            if (item.note.isNotBlank()) card.addView(label("یادداشت: ${item.note}", 14f, false))
            val del = Button(this).apply {
                text = "حذف کلاس"
                setOnClickListener {
                    cancel(item)
                    classes.removeAll { it.id == item.id }
                    saveClasses(); renderClasses()
                }
            }
            card.addView(del)
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 18
            listBox.addView(card, lp)
        }
    }

    private fun nextTrigger(item: UniClass, minutesBefore: Int): Long {
        val now = System.currentTimeMillis()
        val c = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_WEEK, item.day)
            set(Calendar.HOUR_OF_DAY, item.hour); set(Calendar.MINUTE, item.minute)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        c.add(Calendar.MINUTE, -minutesBefore)
        if (c.timeInMillis <= now) c.add(Calendar.DAY_OF_MONTH, 7)
        return c.timeInMillis
    }

    private fun pendingIntent(item: UniClass, mins: Int): PendingIntent {
        val intent = Intent(this, ReminderReceiver::class.java).apply {
            putExtra("classId", item.id); putExtra("name", item.name)
            putExtra("note", item.note); putExtra("minutes", mins)
            putExtra("day", item.day); putExtra("hour", item.hour); putExtra("minute", item.minute)
            putExtra("room", item.room)
        }
        return PendingIntent.getBroadcast(this, item.id * 100 + mins, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun schedule(item: UniClass) {
        val am = getSystemService(AlarmManager::class.java)
        item.reminders.forEach { mins ->
            val pi = pendingIntent(item, mins)
            val trigger = nextTrigger(item, mins)
            try {
                if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
                }
            } catch (_: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
            }
        }
    }

    private fun cancel(item: UniClass) {
        val am = getSystemService(AlarmManager::class.java)
        item.reminders.forEach { am.cancel(pendingIntent(item, it)) }
    }

    private fun saveClasses() {
        val arr = JSONArray()
        classes.forEach { c ->
            arr.put(JSONObject().apply {
                put("id", c.id); put("name", c.name); put("day", c.day)
                put("hour", c.hour); put("minute", c.minute); put("room", c.room); put("note", c.note)
                put("reminders", JSONArray(c.reminders))
            })
        }
        prefs.edit().putString("classes", arr.toString()).apply()
    }

    private fun loadClasses() {
        try {
            val arr = JSONArray(prefs.getString("classes", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i); val r = o.getJSONArray("reminders")
                classes.add(UniClass(o.getInt("id"), o.getString("name"), o.getInt("day"),
                    o.getInt("hour"), o.getInt("minute"), o.optString("room"), o.optString("note"),
                    (0 until r.length()).map { r.getInt(it) }))
            }
        } catch (_: Exception) { }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("class_reminders", "یادآوری کلاس‌ها", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "هشدارهای برنامه‌ریز دانشگاه"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 40)
        }
    }

    private fun label(textValue: String, size: Float, bold: Boolean): TextView =
        TextView(this).apply {
            text = textValue; textSize = size; setTextColor(0xFF202B36.toInt())
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun edit(hintText: String) = EditText(this).apply {
        hint = hintText; textSize = 15f; setSingleLine(false)
        setPadding(18, 14, 18, 14); setBackgroundColor(0xFFFFFFFF.toInt())
    }
    private fun match() = LinearLayout.LayoutParams(-1, -2)
    private fun marginTop(lp: LinearLayout.LayoutParams, top: Int) = lp.apply { topMargin = top }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val name = intent.getStringExtra("name") ?: "کلاس دانشگاه"
        val note = intent.getStringExtra("note") ?: ""
        val mins = intent.getIntExtra("minutes", 0)
        val room = intent.getStringExtra("room") ?: ""
        val title = if (mins == 0) "زمان کلاس رسیده!" else "$mins دقیقه تا کلاس «$name»"
        val body = buildString {
            if (room.isNotBlank()) append("$room\n")
            if (note.isNotBlank()) append(note) else append("برای شروع کلاس آماده شو.")
        }
        val builder = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(context, "class_reminders") else Notification.Builder(context)
        val notification = builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(body).setStyle(Notification.BigTextStyle().bigText(body))
            .setAutoCancel(true).build()
        val nm = context.getSystemService(NotificationManager::class.java)
        try { nm.notify(intent.getIntExtra("classId", 0) * 100 + mins, notification) } catch (_: SecurityException) {}
        // Schedule this same reminder for the following week.
        val id = intent.getIntExtra("classId", 0)
        val day = intent.getIntExtra("day", Calendar.MONDAY)
        val hour = intent.getIntExtra("hour", 9)
        val minute = intent.getIntExtra("minute", 0)
        val next = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_WEEK, day); set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); add(Calendar.MINUTE, -mins)
            while (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_MONTH, 7)
        }
        val again = Intent(context, ReminderReceiver::class.java).apply {
            putExtras(intent); putExtra("classId", id); putExtra("name", name)
            putExtra("note", note); putExtra("minutes", mins); putExtra("day", day)
            putExtra("hour", hour); putExtra("minute", minute); putExtra("room", room)
        }
        val pi = PendingIntent.getBroadcast(context, id * 100 + mins, again,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = context.getSystemService(AlarmManager::class.java)
        try {
            if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms())
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
        } catch (_: Exception) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi) }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences("uni_planner", Context.MODE_PRIVATE)
        try {
            val arr = JSONArray(prefs.getString("classes", "[]"))
            val am = context.getSystemService(AlarmManager::class.java)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i); val r = o.getJSONArray("reminders")
                for (j in 0 until r.length()) {
                    val mins = r.getInt(j); val id = o.getInt("id")
                    val intent2 = Intent(context, ReminderReceiver::class.java).apply {
                        putExtra("classId", id); putExtra("name", o.getString("name"))
                        putExtra("note", o.optString("note")); putExtra("minutes", mins)
                        putExtra("day", o.getInt("day")); putExtra("hour", o.getInt("hour"))
                        putExtra("minute", o.getInt("minute")); putExtra("room", o.optString("room"))
                    }
                    val pi = PendingIntent.getBroadcast(context, id * 100 + mins, intent2,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    val cal = Calendar.getInstance().apply {
                        set(Calendar.DAY_OF_WEEK, o.getInt("day")); set(Calendar.HOUR_OF_DAY, o.getInt("hour"))
                        set(Calendar.MINUTE, o.getInt("minute")); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                        add(Calendar.MINUTE, -mins)
                        while (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_MONTH, 7)
                    }
                    try {
                        if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                    } catch (_: Exception) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi) }
                }
            }
        } catch (_: Exception) { }
    }
}
